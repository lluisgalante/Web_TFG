<?php
session_start();
$_SESSION['theme'] = $_POST['theme'];