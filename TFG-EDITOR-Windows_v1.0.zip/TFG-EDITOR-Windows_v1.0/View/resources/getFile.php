<?php
//$s = file_get_contents("C:\xampp\htdocs\app\temp\5bd79ac.cpp");
$language = strtolower($_POST['language']);
$code = $_POST['code'];

if($language == "python") {
    //$s=file_get_contents("C:/xampp/htdocs/app/temp/0ba764d.python");
}

if($language == "cpp") {
   //$s=file_get_contents("C:/xampp/htdocs/app/temp/5db7d3b.cpp"); 
}


?>